import { motion } from 'framer-motion';
import { BarChart3, Globe2, MessageSquare, Target } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const features = [
    {
      icon: <Globe2 className="w-8 h-8 text-blue-600" />,
      title: 'AI-Powered Matching',
      description: 'Smart algorithms connect you with the perfect influencers for your brand.'
    },
    {
      icon: <Target className="w-8 h-8 text-blue-600" />,
      title: 'Area-Based Marketing',
      description: 'Target specific locations and demographics with precision.'
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-blue-600" />,
      title: 'Advanced Analytics',
      description: 'Track campaign performance with detailed insights and metrics.'
    },
    {
      icon: <MessageSquare className="w-8 h-8 text-blue-600" />,
      title: 'Content Support',
      description: 'Get expert guidance on content strategy and creation.'
    }
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      role: 'Fashion Boutique Owner',
      image: 'https://source.unsplash.com/ZHvM3XIOHoE/400x400',
      testimonial: 'FindoBrand connected us with fashion influencers who perfectly represented our brand. Our sales increased by 60% in just two months!',
      businessImage: 'https://source.unsplash.com/gf8e6XvG_3E/400x400'
    },
    {
      name: 'Rajesh Kumar',
      role: 'Restaurant Chain Owner',
      image: 'https://source.unsplash.com/7YVZYZeITc8/400x400',
      testimonial: 'The local food bloggers we found through FindoBrand brought in a wave of new customers. Our weekend bookings are now always full!',
      businessImage: 'https://source.unsplash.com/MQUqbmszGGM/400x400'
    },
    {
      name: 'Anita Desai',
      role: 'Wellness Center Director',
      image: 'https://source.unsplash.com/rDEOVtE7vOs/400x400',
      testimonial: 'Working with wellness influencers through FindoBrand helped us reach our target audience effectively. Our client base grew by 45%.',
      businessImage: 'https://source.unsplash.com/NTyBbu66_SI/400x400'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://source.unsplash.com/random/1920x1080?marketing')] bg-cover bg-center opacity-10"></div>
        </div>
        <div className="container-custom relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Bridge the Gap Between Local Brands & Influencers
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Connect with the perfect influencers for your local business and watch your brand grow.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/join" className="btn-primary bg-white text-blue-600 hover:bg-blue-50">
                Join as Business
              </Link>
              <Link to="/join" className="btn-secondary border-white text-white hover:bg-blue-700">
                Join as Influencer
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose FindoBrand?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="card hover:shadow-xl transition-shadow bg-gradient-to-br from-white to-blue-50"
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-to-b from-white to-blue-50">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="card overflow-hidden"
              >
                <div className="relative h-48 mb-6">
                  <img
                    src={testimonial.businessImage}
                    alt="Business"
                    className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                  />
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-20 h-20 rounded-full border-4 border-white shadow-lg"
                    />
                  </div>
                </div>
                <div className="text-center mt-8">
                  <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                  <p className="text-blue-600 text-sm mb-4">{testimonial.role}</p>
                  <p className="text-gray-600 italic">"{testimonial.testimonial}"</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <h3 className="text-4xl font-bold mb-2">2000+</h3>
              <p>Active Businesses</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold mb-2">5000+</h3>
              <p>Influencers</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold mb-2">15K+</h3>
              <p>Successful Campaigns</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold mb-2">50+</h3>
              <p>Cities Covered</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}