import { motion } from 'framer-motion';
import { Calendar, Image, MapPin, Target, Users } from 'lucide-react';
import { useState } from 'react';

export default function Campaign() {
  const [step, setStep] = useState(1);

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Create New Campaign</h1>

          {/* Progress Steps */}
          <div className="flex justify-between mb-8">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`w-1/4 h-2 rounded-full ${
                  s <= step ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>

          {/* Step Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-md p-8"
          >
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">Campaign Details</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Campaign Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="Enter campaign name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    className="w-full px-4 py-2 border rounded-lg"
                    rows={4}
                    placeholder="Describe your campaign objectives"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      className="w-full px-4 py-2 border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      End Date
                    </label>
                    <input
                      type="date"
                      className="w-full px-4 py-2 border rounded-lg"
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">Target Audience</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Target Location
                  </label>
                  <select className="w-full px-4 py-2 border rounded-lg">
                    <option value="">Select location</option>
                    <option value="mumbai">Mumbai</option>
                    <option value="delhi">Delhi</option>
                    <option value="bangalore">Bangalore</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Age Range
                  </label>
                  <div className="flex gap-4">
                    <input
                      type="number"
                      className="w-full px-4 py-2 border rounded-lg"
                      placeholder="Min age"
                    />
                    <input
                      type="number"
                      className="w-full px-4 py-2 border rounded-lg"
                      placeholder="Max age"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Interests
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {['Fashion', 'Beauty', 'Lifestyle', 'Food', 'Tech', 'Travel'].map((interest) => (
                      <label
                        key={interest}
                        className="flex items-center p-2 border rounded-lg cursor-pointer hover:bg-gray-50"
                      >
                        <input type="checkbox" className="mr-2" />
                        {interest}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">Campaign Content</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Content Type
                  </label>
                  <select className="w-full px-4 py-2 border rounded-lg">
                    <option value="">Select content type</option>
                    <option value="photo">Photo Post</option>
                    <option value="video">Video Content</option>
                    <option value="story">Story</option>
                    <option value="reel">Reel</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Content Guidelines
                  </label>
                  <textarea
                    className="w-full px-4 py-2 border rounded-lg"
                    rows={4}
                    placeholder="Describe your content requirements and guidelines"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Reference Images
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Image className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">
                      Drag and drop images here or click to upload
                    </p>
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">Budget & Goals</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Campaign Budget
                  </label>
                  <input
                    type="number"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="Enter budget amount"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Expected Reach
                  </label>
                  <input
                    type="number"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="Enter expected reach"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Campaign Goals
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { icon: Users, label: 'Brand Awareness' },
                      { icon: Target, label: 'Sales' },
                      { icon: MapPin, label: 'Local Reach' },
                      { icon: Calendar, label: 'Event Promotion' }
                    ].map((goal) => (
                      <label
                        key={goal.label}
                        className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50"
                      >
                        <input type="checkbox" className="mr-3" />
                        <goal.icon className="w-5 h-5 text-blue-600 mr-2" />
                        {goal.label}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              {step > 1 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="btn-secondary"
                >
                  Back
                </button>
              )}
              <button
                onClick={() => step < 4 ? setStep(step + 1) : alert('Campaign created!')}
                className="btn-primary ml-auto"
              >
                {step === 4 ? 'Create Campaign' : 'Next'}
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}