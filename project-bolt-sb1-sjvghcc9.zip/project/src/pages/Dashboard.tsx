import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { BarChart, Bell, LineChart, MapPin, Settings, TrendingUp, User, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Area, AreaChart, Bar, BarChart as RechartsBarChart, CartesianGrid, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const areaChartData = [
  { date: '2024-03-01', value: 2400 },
  { date: '2024-03-02', value: 1398 },
  { date: '2024-03-03', value: 9800 },
  { date: '2024-03-04', value: 3908 },
  { date: '2024-03-05', value: 4800 },
  { date: '2024-03-06', value: 3800 },
  { date: '2024-03-07', value: 4300 },
].map(item => ({
  ...item,
  date: format(new Date(item.date), 'MMM d'),
}));

const pieChartData = [
  { name: 'Instagram', value: 400 },
  { name: 'YouTube', value: 300 },
  { name: 'TikTok', value: 300 },
  { name: 'Blog Posts', value: 200 },
];

const barChartData = [
  { name: 'Jan', value: 4000 },
  { name: 'Feb', value: 3000 },
  { name: 'Mar', value: 2000 },
];

export default function Dashboard() {
  const metrics = [
    { title: 'Total Reach', value: '45.2K', icon: Users, trend: '+12%', color: 'blue' },
    { title: 'Engagement Rate', value: '4.8%', icon: TrendingUp, trend: '+2.4%', color: 'green' },
    { title: 'Active Campaigns', value: '3', icon: BarChart, trend: '0%', color: 'purple' },
    { title: 'Cities Covered', value: '5', icon: MapPin, trend: '+1', color: 'orange' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-white border-b">
        <div className="container-custom">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <div className="flex items-center space-x-4">
              <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
                <Bell size={20} />
              </button>
              <Link to="/profile" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-lg">
                <img
                  src="https://source.unsplash.com/7YVZYZeITc8/100x100"
                  alt="Profile"
                  className="w-8 h-8 rounded-full"
                />
                <span className="font-medium">John's Fashion</span>
              </Link>
              <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
                <Settings size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container-custom py-8">
        {/* Quick Actions */}
        <div className="flex gap-4 mb-8">
          <Link to="/campaign/new" className="btn-primary flex items-center gap-2">
            <BarChart size={20} />
            Create Campaign
          </Link>
          <Link to="/profile" className="btn-secondary flex items-center gap-2">
            <User size={20} />
            View Profile
          </Link>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className={`bg-gradient-to-br from-${metric.color}-50 to-white rounded-lg p-6 shadow-md`}
            >
              <div className="flex items-center justify-between mb-4">
                <metric.icon className={`w-6 h-6 text-${metric.color}-600`} />
                <span className={`text-sm ${
                  metric.trend.startsWith('+') ? 'text-green-500' : 'text-gray-500'
                }`}>
                  {metric.trend}
                </span>
              </div>
              <h3 className="text-gray-600 text-sm mb-1">{metric.title}</h3>
              <p className="text-2xl font-bold">{metric.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-lg p-6 shadow-md"
          >
            <h3 className="text-lg font-semibold mb-4">Engagement Overview</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={areaChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="value" stroke="#2563eb" fill="#93c5fd" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-lg p-6 shadow-md"
          >
            <h3 className="text-lg font-semibold mb-4">Campaign Performance</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={barChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#2563eb" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Content Distribution */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg p-6 shadow-md"
          >
            <h3 className="text-lg font-semibold mb-4">Content Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label
                  />
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2 bg-white rounded-lg p-6 shadow-md"
          >
            <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {[
                {
                  title: 'Summer Collection Campaign Started',
                  description: 'Collaboration with @fashion.style',
                  time: '2 hours ago',
                  image: 'https://source.unsplash.com/mEZ3PoFGs_k/100x100'
                },
                {
                  title: 'New Influencer Partnership',
                  description: 'Connected with @lifestyle.guru',
                  time: '5 hours ago',
                  image: 'https://source.unsplash.com/7YVZYZeITc8/100x100'
                },
                {
                  title: 'Campaign Analytics Updated',
                  description: 'Spring Collection performance report',
                  time: '1 day ago',
                  image: 'https://source.unsplash.com/WNoLnJo7tS8/100x100'
                }
              ].map((activity, index) => (
                <div key={index} className="flex items-center gap-4 p-4 hover:bg-gray-50 rounded-lg transition-colors">
                  <img
                    src={activity.image}
                    alt=""
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium">{activity.title}</h4>
                    <p className="text-sm text-gray-600">{activity.description}</p>
                  </div>
                  <span className="text-sm text-gray-500">{activity.time}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}