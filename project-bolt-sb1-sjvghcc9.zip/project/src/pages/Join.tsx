import { motion } from 'framer-motion';
import { Building2, User } from 'lucide-react';
import { useState } from 'react';

type UserType = 'retailer' | 'influencer' | null;

export default function Join() {
  const [userType, setUserType] = useState<UserType>(null);
  const [step, setStep] = useState(1);

  const renderForm = () => {
    if (!userType) return null;

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md mx-auto"
      >
        <div className="flex justify-between mb-8">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`w-1/3 h-2 rounded-full ${
                s <= step ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold mb-4">Basic Information</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border rounded-lg"
                placeholder="Enter your full name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                className="w-full px-4 py-2 border rounded-lg"
                placeholder="Enter your email"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone
              </label>
              <input
                type="tel"
                className="w-full px-4 py-2 border rounded-lg"
                placeholder="Enter your phone number"
              />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold mb-4">
              {userType === 'retailer' ? 'Business Details' : 'Social Media Details'}
            </h3>
            {userType === 'retailer' ? (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Business Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="Enter your business name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Business Category
                  </label>
                  <select className="w-full px-4 py-2 border rounded-lg">
                    <option value="">Select category</option>
                    <option value="retail">Retail</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="services">Services</option>
                  </select>
                </div>
              </>
            ) : (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Content Category
                  </label>
                  <select className="w-full px-4 py-2 border rounded-lg">
                    <option value="">Select category</option>
                    <option value="fashion">Fashion</option>
                    <option value="food">Food</option>
                    <option value="tech">Tech</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Instagram Handle
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="@username"
                  />
                </div>
              </>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold mb-4">Location & Preferences</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                City
              </label>
              <select className="w-full px-4 py-2 border rounded-lg">
                <option value="">Select city</option>
                <option value="mumbai">Mumbai</option>
                <option value="delhi">Delhi</option>
                <option value="bangalore">Bangalore</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Preferred Areas
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border rounded-lg"
                placeholder="Enter areas you operate in"
              />
            </div>
          </div>
        )}

        <div className="flex justify-between mt-8">
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="btn-secondary"
            >
              Back
            </button>
          )}
          <button
            onClick={() => step < 3 ? setStep(step + 1) : alert('Form submitted!')}
            className="btn-primary ml-auto"
          >
            {step === 3 ? 'Submit' : 'Next'}
          </button>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Join FindoBrand</h1>
          <p className="text-gray-600">
            Choose your role and start your journey with us
          </p>
        </div>

        {!userType ? (
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="card cursor-pointer hover:border-blue-600 border-2"
              onClick={() => setUserType('retailer')}
            >
              <div className="flex flex-col items-center text-center">
                <Building2 className="w-16 h-16 text-blue-600 mb-4" />
                <h2 className="text-2xl font-semibold mb-2">I'm a Retailer</h2>
                <p className="text-gray-600">
                  Connect with influencers to promote your local business
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="card cursor-pointer hover:border-blue-600 border-2"
              onClick={() => setUserType('influencer')}
            >
              <div className="flex flex-col items-center text-center">
                <User className="w-16 h-16 text-blue-600 mb-4" />
                <h2 className="text-2xl font-semibold mb-2">I'm an Influencer</h2>
                <p className="text-gray-600">
                  Partner with local businesses and grow your influence
                </p>
              </div>
            </motion.div>
          </div>
        ) : (
          renderForm()
        )}
      </div>
    </div>
  );
}