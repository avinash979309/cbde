import { motion } from 'framer-motion';
import { Filter, Search, Star } from 'lucide-react';
import { useState } from 'react';

const categories = ['All', 'Fashion', 'Food', 'Tech', 'Lifestyle', 'Beauty'];
const locations = ['All', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad'];
const followerRanges = ['All', '10K-50K', '50K-100K', '100K-500K', '500K+'];

interface Influencer {
  id: number;
  name: string;
  category: string;
  location: string;
  followers: string;
  rating: number;
  image: string;
  bio: string;
  instagram: string;
  engagement: string;
}

const influencers: Influencer[] = [
  {
    id: 1,
    name: "Aisha Patel",
    category: "Fashion",
    location: "Mumbai",
    followers: "250K",
    rating: 4.8,
    image: "https://source.unsplash.com/mEZ3PoFGs_k/400x400",
    bio: "Fashion & Lifestyle blogger sharing daily style inspiration",
    instagram: "@aisha.styles",
    engagement: "5.2%"
  },
  {
    id: 2,
    name: "Vikram Singh",
    category: "Food",
    location: "Delhi",
    followers: "180K",
    rating: 4.7,
    image: "https://source.unsplash.com/WNoLnJo7tS8/400x400",
    bio: "Food critic & culinary explorer showcasing India's best restaurants",
    instagram: "@vikram.foodie",
    engagement: "4.8%"
  },
  {
    id: 3,
    name: "Priya Mehta",
    category: "Beauty",
    location: "Bangalore",
    followers: "420K",
    rating: 4.9,
    image: "https://source.unsplash.com/7YVZYZeITc8/400x400",
    bio: "Beauty expert sharing skincare tips & makeup tutorials",
    instagram: "@priya.beauty",
    engagement: "6.1%"
  },
  {
    id: 4,
    name: "Arjun Kumar",
    category: "Tech",
    location: "Hyderabad",
    followers: "150K",
    rating: 4.6,
    image: "https://source.unsplash.com/WNoLnJo7tS8/400x400",
    bio: "Tech reviewer & gadget enthusiast",
    instagram: "@techwitharjun",
    engagement: "4.5%"
  },
  {
    id: 5,
    name: "Neha Sharma",
    category: "Lifestyle",
    location: "Mumbai",
    followers: "320K",
    rating: 4.8,
    image: "https://source.unsplash.com/mEZ3PoFGs_k/400x400",
    bio: "Lifestyle blogger sharing travel & wellness tips",
    instagram: "@neha.lifestyle",
    engagement: "5.5%"
  },
  {
    id: 6,
    name: "Rahul Verma",
    category: "Food",
    location: "Chennai",
    followers: "280K",
    rating: 4.7,
    image: "https://source.unsplash.com/7YVZYZeITc8/400x400",
    bio: "Street food explorer & restaurant reviewer",
    instagram: "@foodwithrahul",
    engagement: "5.8%"
  }
];

export default function Explore() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [selectedFollowerRange, setSelectedFollowerRange] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const getFollowerCount = (followers: string) => {
    return parseInt(followers.replace(/[^0-9]/g, ''));
  };

  const isInFollowerRange = (followers: string, range: string) => {
    const count = getFollowerCount(followers);
    switch (range) {
      case '10K-50K': return count >= 10 && count < 50;
      case '50K-100K': return count >= 50 && count < 100;
      case '100K-500K': return count >= 100 && count < 500;
      case '500K+': return count >= 500;
      default: return true;
    }
  };

  const filteredInfluencers = influencers.filter(influencer => {
    const matchesCategory = selectedCategory === 'All' || influencer.category === selectedCategory;
    const matchesLocation = selectedLocation === 'All' || influencer.location === selectedLocation;
    const matchesFollowers = selectedFollowerRange === 'All' || isInFollowerRange(influencer.followers, selectedFollowerRange);
    const matchesSearch = influencer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         influencer.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         influencer.bio.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesLocation && matchesFollowers && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-12">
      <div className="container-custom">
        <h1 className="text-4xl font-bold mb-8">Explore Influencers</h1>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Search influencers..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-4">
              <select
                className="px-4 py-2 border rounded-lg"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
              <select
                className="px-4 py-2 border rounded-lg"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
              >
                {locations.map(location => (
                  <option key={location} value={location}>{location}</option>
                ))}
              </select>
              <select
                className="px-4 py-2 border rounded-lg"
                value={selectedFollowerRange}
                onChange={(e) => setSelectedFollowerRange(e.target.value)}
              >
                {followerRanges.map(range => (
                  <option key={range} value={range}>
                    {range === 'All' ? 'All Followers' : range + ' followers'}
                  </option>
                ))}
              </select>
              <button className="btn-secondary flex items-center gap-2">
                <Filter size={20} />
                More Filters
              </button>
            </div>
          </div>
        </div>

        {/* Influencer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredInfluencers.map((influencer, index) => (
            <motion.div
              key={influencer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow"
            >
              <div className="relative">
                <img
                  src={influencer.image}
                  alt={influencer.name}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <h3 className="font-semibold text-lg text-white">{influencer.name}</h3>
                  <p className="text-blue-200">{influencer.instagram}</p>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                  <span className="px-2 py-1 bg-blue-100 text-blue-600 rounded-full">{influencer.category}</span>
                  <span>•</span>
                  <span>{influencer.location}</span>
                </div>
                <p className="text-gray-600 text-sm mb-4">{influencer.bio}</p>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span>{influencer.rating}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-gray-900">{influencer.followers} followers</div>
                    <div className="text-xs text-gray-600">{influencer.engagement} engagement</div>
                  </div>
                </div>
                <button className="w-full btn-primary">Connect</button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}